To use this module, you need to:

#. Go to Sales -> Configuration -> Settings -> Pricing -> Sale Price and
   activate: "Advanced pricing based on formulas (discounts, margins,
   rounding)"
#. Go to Sales -> Configuration -> Price-list and edit an existing one or
   create a new one
#. In the pricelist -> add a new item or open a new one
#. You will find the field commission in the pricelist item
