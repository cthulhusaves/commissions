[![Build Status](https://travis-ci.org/OCA/commission.svg?branch=11.0)](https://travis-ci.org/OCA/commission)
[![Coverage Status](https://coveralls.io/repos/OCA/commission/badge.png?branch=11.0)](https://coveralls.io/r/OCA/commission?branch=11.0)

Odoo Commission Management
==========================

All management related with commisions and incentive in Odoo.


