* Make it totally multi-company aware.
* Allow to calculate and pay in other currency different from company one.
* Allow to group by agent when generating invoices.
* Set agent popup window with a kanban view with richer information and
  mobile friendly.
