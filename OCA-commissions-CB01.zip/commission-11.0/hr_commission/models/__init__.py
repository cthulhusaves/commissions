from . import hr_employee
from . import res_partner
