* Add demo data.
* Link settlements with wages.
