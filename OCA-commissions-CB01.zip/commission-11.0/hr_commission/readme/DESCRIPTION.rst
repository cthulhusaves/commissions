This module links sale_commission with hr module. For now, it only adds another
type of agent whose commissions are not invoiced in the corresponding wizard.
